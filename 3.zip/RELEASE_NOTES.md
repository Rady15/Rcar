# Release Notes

This release includes customer registration, Google Sign-In, invoice-only printing, SEO crawl endpoints, release security cleanup and production smoke coverage.
