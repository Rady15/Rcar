import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: { alias: { '@': path.resolve(__dirname, '.') } },
  server: { host: '0.0.0.0', port: 5173, hmr: process.env.DISABLE_HMR !== 'true' },
  build: { sourcemap: true, target: 'es2022' },
});
